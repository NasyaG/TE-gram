<template>
  <div class="post">
    <div id="post-part1">
        <!-- <router-link v-bind:to="{name: 'profile-by-id'}" v-bind:userId="post.post.userId" > 
            <h3 class="post-username" v-on:click="viewSelectedUserProfile">{{post.username}}{{post.post.userId}}</h3>
        </router-link> -->

            <h3 class="post-username" v-on:click="viewSelectedUserProfile"  >{{post.username}}</h3>
      
      
        <img v-bind:src="post.photo.photo" alt="" />
    </div>
    <div id="post-part2">
        <div class="interact">
            <font-awesome-icon icon="fa-solid fa-heart" class="icon"  
                                v-on:click="likePost" 
                                :class="{'selected' : isLiked}"/>
            <font-awesome-icon icon="fa-solid fa-comment" class="icon" v-on:click="displayComments"/>
            <font-awesome-icon icon="fa-solid fa-bookmark" class="icon"
                                v-on:click="savePost" 
                                :class="{'selected' : isSaved}"/>
        </div>
        <span class="date">{{getHumanDate}}</span><span class="numberOfLikes">{{numberOfLikes}}</span>
        
        <div class="post-caption">
            <p>{{post.post.caption}}</p>
        </div>
         <list-comments v-bind:post="post" v-if="showComments || windowWidth > 768"/>
    </div>
  </div>
</template>

<script>
import ListComments from './ListComments.vue';
import moment from 'moment';
import ApiServices from '../services/ApiServices';
export default {
  components: { ListComments },
    name: 'display-post',
    props: ['post'],
    data(){
        return{
            photoBase: "data:image/jpeg;base64,",
            showComments: false,
            isLiked: false,
            isSaved: false,
        }
    },
    computed: {
        getHumanDate() {
                return moment(this.post.post.uploadTime).fromNow();
                //return moment(this.post.post.uploadTime, 'YYYY-MM-DD').format('MMMM Do YYYY');
        },
        windowWidth() {
            return this.$store.state.windowWidth;
        },
        numberOfLikes() {
            if(this.post.post.likes == 1){
                return `${this.post.post.likes} like`
            }else{
                return `${this.post.post.likes} likes`
            }
        }       
    },
    created(){
        this.isLiked = this.post.post.liked;
        this.isSaved = this.post.post.favorited;
    },
    // watch: {
    //     windowWidth: function() {
    //         if (this.windowWidth === 768) {
    //         this.showComments = true
    //         }
    //     }
    // },
    methods:{
       
        likePost(){
            this.isLiked = !this.isLiked;
             if(this.isLiked){
                //alert("Liking Post")
                ApiServices.likePost(this.post.post.postId, this.$store.state.user.userId).then(response => {
                    console.log(response.data)
                });
            }else if(!this.isLiked){
                //alert("un liking post")
                ApiServices.unlikePost(this.post.post.postId, this.$store.state.user.userId).then(response => {
                    console.log(response.data)
                });
            }
        },
        savePost(){
            this.isSaved = !this.isSaved;
            if(this.isSaved){
                //alert("saving w/ this is saved")
                ApiServices.favoritePost(this.post.post.postId, this.$store.state.user.userId).then(response => {
                    console.log(response.data)
                });
            }else if(!this.isSaved){
                //alert("un-saving or un favoriting post")
                ApiServices.unfavoritePost(this.post.post.postId, this.$store.state.user.userId).then(response => {
                    console.log(response.data)
                });
            }
        },
        displayComments(){
            this.showComments = !this.showComments;
            console.log(this.post.commentsList.comment);
        },
        viewSelectedUserProfile(){
            this.$router.replace({name:'profile-by-id', params:{'userId': this.post.post.userId}})
        }
        
        
        
    }
}
</script>

<style>
.post{
    background-color: white;
    display: flex;
    flex-direction: column;
    justify-content: center;
    /* align-items: center; */
    border-radius: 20px;
    margin: 1rem 0 1rem 0;
}
.post img{
    width: 100%;
    max-height: 400;
    border:  4px ;
    margin: 0 0 0 0;

}
.post-username{
    color: #A8248E ;
    margin: 0 0 0 1rem;
    padding: 1rem 0 0 0;
    cursor: pointer;
}
.interact {
    
    display: flex;
    justify-content: left;
    align-items: center;
    width: 100%;
    border: 4px ;
    border-bottom-left-radius: 5px;
    border-bottom-right-radius: 5px;
}
.icon{
    padding: 1vh;
    color: #f0d10c;
    cursor: pointer;
}
.numberOfLikes{
    color: #ddcbef
}
.date{
    padding: 4px;
    font-weight: bold;
    color: #A8248E;
}
.selected{
    color: #A8248E;
}
.post-caption{
    margin: 0;
    color: #A8248E;
}
@media only screen and (min-width: 768px){
    .post{
    flex-direction: row;
    justify-content: center;
    align-items: center;
    border-radius: 20px;
    margin: 1rem 0 1rem 0;
    }
    #post-part1{
        width: 55%;
    }
    #post-part2{
        width: 45%;
        margin-left: 1rem;
    }
    .post-username{
    color: #A8248E ;
    margin: 0 0 0 0;
    padding: 1rem 0 0 0;
}
    
}
</style>