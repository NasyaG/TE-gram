<template>
  <div>
      <img src="../assets/spinner-loading.gif" alt="loading image" id="loading-image">
  </div>
</template>

<script>
export default {
name: "loading-logo",
}
</script>

<style>

</style>