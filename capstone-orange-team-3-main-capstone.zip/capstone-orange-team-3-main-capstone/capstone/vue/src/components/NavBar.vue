<template>
<div>
    <div v-show="hover" id="total-likes-container"><span id="total-likes">Total Likes: {{totalLikes}}</span></div>
  <div id="nav-bar">
        <span id="always-here">.</span>

        <router-link v-bind:to="{ name: 'home' }" v-show="$store.state.token != ''" >
            <font-awesome-icon icon="fa-solid fa-house-chimney" class="menu-icon"
                               :class="{'on-this-page': onHomePage}"
                               v-on:click="onHomePageToggle"/>
        </router-link>
        
        <router-link v-bind:to="{name: 'create-post' }" v-show="$store.state.token != ''" >
            <font-awesome-icon icon="fa-solid fa-square-plus" class="menu-icon" 
                               :class="{'on-this-page': onCreatePost}"
                               v-on:click="onCreatePostToggle"/>
                               
        </router-link>
        
        <router-link v-bind:to="{name: 'comment-notifications' }" v-show="$store.state.token != ''" >
            <font-awesome-icon icon="fa-solid fa-comment"  class="menu-icon"
                               :class="{'on-this-page': onCommentNotification}"
                               v-on:click="onCommentNotificationToggle"/>
        </router-link>

        <label  v-show="$store.state.token != ''" >
            <font-awesome-icon icon="fa-solid fa-heart" class="menu-icon"
                               :class="{'on-this-page': onLikeNotification}"
                               v-on:click="getTotalLikes"
                               @mouseover="hover = true"
                                @mouseleave="hover = false"
                               />
                                
        </label>

        <router-link v-bind:to="{name: 'profile' }" v-show="$store.state.token != ''" v-on:click="toggleUserInfoSb" >
        <font-awesome-icon icon="fa-solid fa-user" class="menu-icon" 
                           :class="{'on-this-page': onProfilePage}"
                           v-on:click="onProfilePageToggle"/>
        </router-link>

        <span id="always-here">.</span>        
  </div>
</div>
</template>

<script>
export default {
    components: {  },
    name: 'nav-bar',
    data(){
        return{
            hover: false,
            onHomePage : true,
            onCreatePost : false,
            onCommentNotification : false,
            onLikeNotification : false,
            onProfilePage : false,
            totalLikes : '',
        }
    },

    methods: {
        toggleUserInfoSb(){
            this.$store.commit("TOGGLE_USER_SIDEBAR");
        },
        getTotalLikes(){
            this.totalLikes = this.$store.state.totalLikes;
        },
        
        onHomePageToggle(){
             this.onHomePage = true,
            this.onCreatePost = false,
            this.onCommentNotification = false,
            this.onLikeNotification = false,
            this.onProfilePage = false
        },
         onCreatePostToggle(){
             this.onHomePage = false,
            this.onCreatePost = true,
            this.onCommentNotification = false,
            this.onLikeNotification = false,
            this.onProfilePage = false
        },
         onCommentNotificationToggle(){
             this.onHomePage = false,
            this.onCreatePost = false,
            this.onCommentNotification = true,
            this.onLikeNotification = false,
            this.onProfilePage = false
        },
         onLikeNotificationToggle(){
            this.getTotalLikes(); 
            this.onLikeNotification = true;
        },
         offLikeNotificationToggle(){
             this.onLikeNotificationToggle = false;
         },
         onProfilePageToggle(){
             this.onHomePage = false,
            this.onCreatePost = false,
            this.onCommentNotification = false,
            this.onLikeNotification = false,
            this.onProfilePage = true
        },
    }

}
</script>

<style>
#nav-bar{
    display: flex;
    justify-content: space-evenly;
    align-items: center;
    background-color: white;
    position: fixed;
    bottom: 0;
    z-index: 11;
    width: 100%;
    height: 2rem;
}
#total-likes-container{
    width: 100%;
    height: 4rem;
    position: fixed;
    display: flex;
    bottom:1rem;
    justify-content: center;
    align-items: center;
    background-color: #ddcbefdc ;
}
#total-likes{
    display: flex;
    align-items: center;
    border-radius: 10px;
    color: #A8248E;
    z-index: 12;
    padding: 10px 10px 10px 30%;
    margin-top: .5rem;
    margin-bottom: 2rem;
    font-size: 1.2rem;
}
.menu-icon{
    padding: 1vh;
    color:  #A8248E;
    cursor: pointer;
}
#always-here{
    color: white;
    height: 2rem;
}
.on-this-page{
    color: #ddcbef;
}
</style>