<template>
<div>
  <div id="comments-list-container">
      <display-comment v-for="comment in post.commentsList" v-bind:key="comment.commentId" v-bind:comment="comment" />
      <display-comment v-if="addedComment != null" v-bind:comment="addedComment" id="newly-added-comment" />
      <input type="textarea" id="add-comment-text" v-model="newCommentText"/>
      <input type="button" id="add-comment-button" class="button" v-on:click="submitNewComment" value="comment" />
   </div>
</div>
</template>

<script>
import ApiServices from '../services/ApiServices'
import DisplayComment from './DisplayComment.vue'
export default {
  components: { DisplayComment },
  name: 'list-comments',
  props: ["post"],
  data(){
    return{
        newCommentText: null,
        addedComment: null
    
    }
  },
  methods:{
    submitNewComment(){
      let comment = {
        UserId: this.$store.state.user.userId,
        PostId: this.post.post.postId,
        Comment: this.newCommentText
      }
      ApiServices.addComment(comment, this.$store.state.token).then(response => {
        this.newCommentText = null;
        this.addedComment = response.data;
        console.log(this.addedComment);

      });


    }
  }
}
</script>

<style>
#list-comments-container{
  border: red solid 1px;
  display: flex;
  flex-direction: column;
  width: 90vw;
  height: 20vw;
  padding: 10px
}
#add-comment-text{
  background-color:#FBF8CC;
  color: #A8248E;
  border-radius: 20px;
  border: 1px solid #A8248E;
  padding: 5px 10px 5px 10px;
  margin: 5px 10px 5px 10px;
}
#newly-added-comment{
    background-color: #FEF19A;
    border-radius: 5px;
    margin: 5px
}
@media only screen and (min-width: 768px){
    #add-comment-text{
      margin: 1rem 0 0 -2px;
    }
    #add-comment-button{
      margin: 4px 0 0 -2px;
    }
    
}
</style>