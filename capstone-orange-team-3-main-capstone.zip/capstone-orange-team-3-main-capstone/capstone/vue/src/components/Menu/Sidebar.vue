<template>
    <div v-show="$store.state.token != ''" >
        <button id="sidebar-button" class="button" type="button" @click="isPanelOpen = !isPanelOpen">
            <font-awesome-icon icon="fa-solid fa-bars" />
        </button>

        <div class="sidebar">
            <div class="sidebar-backdrop" @click="closeSidebarPanel" v-if="isPanelOpen"></div>
            <transition name="slide">
                <div v-if="isPanelOpen"
                    class="sidebar-panel">
                    <slot></slot>

                    <router-link class="router-link" v-bind:to="{ name: 'home' }" v-if="$store.state.token != ''">Home</router-link>
                    
                    <nav>
                    <router-link class="router-link" v-bind:to="{ name: 'logout' }" v-on:click="closeSidebarPanel" v-if="$store.state.token != ''"> <span v-on:click="closeSidebarPanel">Logout</span> </router-link>
                    </nav>
                    <router-link class="router-link" :to="{ name: 'login' }" v-if="$store.state.token == ''" >Login</router-link>

                    <div>
                        <router-link class="router-link" :to="{ name: 'register' }"  v-if="$store.state.token == ''" >Register</router-link>
                    </div>

                <div>
                    <router-link class="router-link" :to="{ name: 'it-support'}"  v-if="$store.state.token == ''">Reset password</router-link>
                </div>

                </div>
            </transition>
        </div>
    </div> 
</template>

<script>
    export default {
        data: () => ({
            isPanelOpen: false,
        }),
        methods: {
            closeSidebarPanel() {
                this.isPanelOpen = false
            }
      
      }
    } 
</script>

<style>
    #sidebar-button{
        position: fixed;
        top: -4px;
        left: 0;
        width: auto;
        z-index: 2;
    }
    .slide-enter-active,
    .slide-leave-active
    {
        transition: transform 0.2s ease;
    }

    .slide-enter,
    .slide-leave-to {
        transform: translateX(-100%);
        transition: all 150ms ease-in 0.2s
    }

    .sidebar-backdrop {
        width: 100%;
        height: 100%;
        
        position: fixed;
        top: 0;
        left: 0;
        cursor: pointer;
    }

    .sidebar-panel {
        overflow-y: auto;
        background-color: #F8DEF3;
        border: solid #A8248E 1px;
        position: fixed;
        left: 0;
        top: 0;
        height: 100%;
        z-index: 0;
        padding: 3rem 20px 2rem 20px;
        width: 20vw;
    }
    .router-link{
        text-decoration: none;
    }

</style>