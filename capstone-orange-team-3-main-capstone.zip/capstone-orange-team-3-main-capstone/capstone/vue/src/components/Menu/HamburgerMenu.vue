<template>
<div class="container-fluid" id="app">
    <nav class="row nav-bar">
        <div class="col-xs-6">
            <div class="logo">
                <span class="logo"></span>
             </div>
        </div>
        
 <div class="col-xs-6">
    <div class="hamburger-wrap">
        <button class="hamburger" type="button" @click="menuOpen = !menuOpen">
        <font-awesome-icon icon="fa-solid fa-bars" />
   
        <span class="hamburger_line"></span>
        <span class="hamburger_middle"></span>
        <span class="icon bar hamburger_line"></span>
        
        </button>
      </div>
   </div>
   </nav>
   <div class="row dropdown" :class="{ 'dropdown-after' : menuOpen }" v-if="menuOpen">
    <ul class="navList">
        <li class="navListItem">
         <router-link v-bind:to="{ name: 'home' }">Home</router-link>&nbsp;|&nbsp;
        </li>
        <li>
         <router-link v-bind:to="{ name: 'logout' }" v-if="$store.state.token != 'logout'">Logout</router-link>
        </li>
        <li>
            <router-link :to="{ name: 'login' }">Have an account?</router-link>
        </li>
        <li>
            <router-link v-bind:to="{ name: 'register' }">Need an account?</router-link>
        </li>
    </ul>
   </div>
 </div>    

    
</template>

<script>

export default{
    el: '#app',
    data(){
        return{
            menuOpen: false
        } //property menu open
    },
   
    // menuOpen: false
    
    //liecycle hook for menu open (setup??)
   
    
    //select element in html??
    //beyond burger icon
};

</script>


<style>
.hamburger{
  background-color: #FBF8CC;
  color: #A8248E;
  border-radius: 20px;
  border: 1px solid  #A8248E;
  margin-top: 20px;

}
</style>