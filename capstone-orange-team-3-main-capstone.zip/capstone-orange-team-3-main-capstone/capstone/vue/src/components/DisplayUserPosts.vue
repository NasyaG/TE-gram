<template>
  <div id="display-user-posts-container">
        <div id="posts-or-saved-container"> 

            <font-awesome-icon icon="fa-solid fa-border-all" class="icon" id="my-posts" 
                                v-on:click="displayFavorited(false)" 
                                :class="{'selected-view': displayUserPosts, 
                                        'not-selected-view': !displayUserPosts}"/>
            
            <font-awesome-icon icon="fa-solid fa-bookmark" class="icon" id="saved-posts" 
                                v-on:click="displayFavorited(true)" 
                                :class="{'selected-view': displaySavedPosts, 
                                        'not-selected-view': !displaySavedPosts}"/>   
        </div>

        <div v-if="displayUserPosts" id="posts-container">
                    <img v-for="post in posts" 
                    v-bind:key="post.post.postId" 
                    v-on:click="displayTheseDetails(post)"
                    :src="post.photo.photo" 
                    alt="post image" 
                    />
        </div>
        
        <div v-if="displaySavedPosts" id="posts-container">
                   <img v-for="post in favoritePosts" 
                    v-bind:key="post.id" 
                    v-on:click="displayTheseDetails(post)" 
                    :src="post.photo.photo" 
                    alt="post image"
                     />
        </div>
        <div v-if="displayDetails" id="details-container">
            <post-full-details v-bind:post="selectedPost" />
        </div>
 </div>
</template>

<script>
import ApiServices from '../services/ApiServices';
import PostFullDetails from './PostFullDetails.vue';
export default {
  components: { PostFullDetails },
    name: 'display-user-posts',
    data(){
        return{
            displayUserPosts: true,
            displaySavedPosts: false,
            displayDetails: false,
            selectedPost: null,
            posts: [],
            favoritePosts: []
        }
    },
    methods: {
        displayFavorited(onOrOffBool){
            this.displayDetails = false;
            this.displaySavedPosts = onOrOffBool;
            this.displayUserPosts = !onOrOffBool;
        },
        displayTheseDetails(post){
            this.selectedPost = post;
            this.displayDetails = true;
            this.displaySavedPosts = false;
            this.displayUserPosts = false;
            
            // in this method, we need to show the post full details view

        }
    },
    created(){
        let totalLikes = 0;
        ApiServices.getUserPosts(this.$store.state.user.userId, this.$store.state.token).then(result => {    
            result.data.forEach(element => {
                element.photo.photo = `${this.$store.state.photoBase}${element.photo.photo}`;
                totalLikes += element.post.likes;
            });
            this.$store.commit("SET_TOTAL_LIKES", totalLikes);
            this.posts = result.data;
        });

        ApiServices.getUserFavoitePosts(this.$store.state.user.userId, this.$store.state.token).then(result => {
            result.data.forEach(element => {
                element.photo.photo = `${this.$store.state.photoBase}${element.photo.photo}`;
            });
            this.favoritePosts = result.data;
        })

    }
}
</script>

<style>
#display-user-posts-container{
    border-radius: 20px;
    padding: 1%
}
#posts-or-saved-container{
    display: flex;
    justify-content: bottom;
    border-bottom: 4px solid #ddcbef; 
    border-right: 4px solid white;  
    border-left: 4px solid white;
}
.not-selected-view{
    width: 45%;
}
.selected-view{
    width:45%;
    background-color: #ddcbef2a;
    border-top-left-radius: 20px;
    border-top-right-radius: 20px; 
}
#posts-container{
margin-top: 70px;
width: 100%;
display: flex;
flex-wrap: wrap;
justify-content: center; 
}
#posts-container img{
    width: 30%;
    margin: 2px 2px 2px 2px;
    object-fit: cover;
}
#my-posts{
    font-size: 1.25rem;
}
@media only screen and (min-width: 1200px){
#posts-container img{
    max-width: 200px;
}
}

</style>