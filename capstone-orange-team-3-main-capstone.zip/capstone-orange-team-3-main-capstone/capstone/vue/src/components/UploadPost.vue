<template>
  <div id="upload-post-container">
        <form id="upload-post-form" action="">
            <label for="file-upload"  id="square-plus">
                    <font-awesome-icon icon="fa-solid fa-square-plus"/>
                <input type="file" v-on:change="assignFile($event)" id="file-upload" style="display:none;" /> 
            </label>
            <img :src="imageUrl" alt="" id="image-preview" />
            

            <textarea id="caption" placeholder="enter caption here" rows="5" cols="40" name="caption" v-model="caption" /> 
            <input class="button" type="button" value="post" id="submit-button" v-on:click="uploadPost"/>
        </form>

        
      
  </div>
</template>

<script>
import ApiServices from "../services/ApiServices";
export default {
    name: 'upload-post',
    data(){
        return{
            image: null,
            caption: '',
            uploadedImageId: null,
            photoBase: "data:image/jpeg;base64,",

        }
    },
    computed: {
        imageUrl(){
            if(this.image != null){
               return URL.createObjectURL(this.image); 
            }
            else{
                return null
            }
        }
    },
    methods:{
        assignFile(event){
            this.image = event.target.files[0];
            console.log(this.image);
        },
        uploadPost(){
            var formData = new FormData();
            formData.append("image", this.image);

            ApiServices
                .addPhoto(formData, this.$store.state.token)
                .then(response => {
                    this.uploadedImageId = response.data;
                    console.log(this.uploadedImageId);

                    let post = {
                        'userId': this.$store.state.user.userId,
                        'photoId': this.uploadedImageId,
                        'caption': this.caption,
                        'liked': false,
                        'likes': 0,
                    };

                    ApiServices
                        .addPost(post, this.$store.state.token)
                        .then(response => {
                            console.log(response);
                        });
                    this.$router. push({ name: "home"}) 
                });

        },

        getPhotoById(){
            ApiServices
                .getPhoto(this.retrievePhotoId, this.$store.state.token)
                .then(response => {
                    this.retrievedPhoto = `${this.photoBase}${response.data.photo}`;
                    
                });
        }


    }
}
</script>

<style>
#file-upload{
    color:#A8248E;
    font-size: 1.75rem;
}
#square-plus{
    background:none;
    border:none;
    margin:0;
    padding:0;
    cursor: pointer;
    color:#A8248E;
    font-size: 1.75rem;
}
.button{
  background-color: #FBF8CC;
  color: #A8248E;
  border-radius: 20px;
  border: 1px solid  #A8248E;
  padding: 5px 10px 5px 10px;
  margin: 5px 5px 5px 5px;
  box-shadow: #A8248E 2px 2px;
  width: auto;
}
  #upload-post-container{
    display: flex;
    flex-direction: column;
    padding: 5px;
    align-items: center;
    margin: 0 0 0 0;
}
  #upload-post-form{
    display: flex;
    flex-direction: column;
    background-color: #F8DEF3;
    width: 100%;
    max-width: 400px;
    min-height: 300px;
    padding: 10px;
    border-radius: 10px;
    align-items: center;
    border: #A8248E solid 1px;
}
#image-preview{
    max-width: 75%;
    margin: 5px;
    justify-content: center;
    background-color: white;

}
textarea{
    max-width: 75%;
}

</style>