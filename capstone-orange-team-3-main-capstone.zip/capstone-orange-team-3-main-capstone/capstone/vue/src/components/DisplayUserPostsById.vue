<template>
  <div id="display-user-posts-container">
        <div id="posts-or-saved-container">            
             <font-awesome-icon icon="fa-solid fa-border-all" class="icon" id="my-posts" 
                                v-on:click="displayFavorited(false)" 
                                :class="{'selected-view': displayUserPosts, 
                                        'not-selected-view': !displayUserPosts}"/>
            
            <font-awesome-icon icon="fa-solid fa-bookmark" class="icon" id="saved-posts" 
                                v-on:click="displayFavorited(true)" 
                                :class="{'selected-view': displaySavedPosts, 
                                        'not-selected-view': !displaySavedPosts}"/>   
        </div>

        <div v-if="displayUserPosts" id="posts-container">
                <img  v-for="post in posts" v-bind:key="post.post.postId" :src="post.photo.photo" alt="post image" v-on:click="displayTheseDetails(post)">
        </div>
        
        <div v-if="displaySavedPosts" id="posts-container">
                   <img v-for="post in favoritePosts" 
                    v-bind:key="post.id" 
                    v-on:click="displayTheseDetails(post)" 
                    :src="post.photo.photo" 
                    alt="post image"
                     />
        </div>
        <div v-if="displayDetails" id="details-container">
            <post-full-details v-bind:post="selectedPost" />
        </div>
 </div>
</template>

<script>
import ApiServices from '../services/ApiServices';
import PostFullDetails from './PostFullDetails.vue';
export default {
  components: { PostFullDetails },
    name: 'display-user-posts-by-id',
    props: ['userId'],
    data(){
        return{
            displayUserPosts: true,
            displaySavedPosts: false,
            displayDetails: false,
            selectedPost: null,
            posts: [],
            favoritePosts: [
                {
                    id: 1,
                    username: "Test User",
                    caption: "This is just a test caption. Dude.. This coding stuff is crazy.",
                    upload_time: "1/1/2022 9:45pm",
                    img_url: "https://static.wixstatic.com/media/8132db_2d74693238194c5784cc457622e0b583~mv2.png/v1/crop/x_0,y_6,w_431,h_269/fill/w_560,h_348,al_c,lg_1,enc_auto/lizzy-eyes_v02.png", 
                    },
                {
                    id: 2,
                    username: "Test User",
                    caption: "This is just a test caption. Dude.. This coding stuff is crazy.",
                    upload_time: "1/1/2022 9:45pm",
                    img_url: "http://rlv.zcache.com/sunglasses_cat_poster-r72e8eac2027d421abd0872bf0bd0e541_wv3_8byvr_325.jpg?bg=0xffffff"
                },
                {
                    id: 3,
                    username: "Test User",
                    caption: "This is just a test caption. Dude.. This coding stuff is crazy.",
                    upload_time: "1/1/2022 9:45pm",
                    img_url: "https://image.shutterstock.com/image-photo/basics-word-made-building-blocks-260nw-584253658.jpg"
                },
                {
                    id: 1,
                    username: "Test User",
                    caption: "This is just a test caption. Dude.. This coding stuff is crazy.",
                    upload_time: "1/1/2022 9:45pm",
                    img_url: "https://image.shutterstock.com/image-photo/basics-word-made-building-blocks-260nw-584253658.jpg"
                }
            ]
        }
    },
    methods: {
        displayFavorited(onOrOffBool){
            this.displayDetails = false;
            this.displaySavedPosts = onOrOffBool;
            this.displayUserPosts = !onOrOffBool;
        },
        displayTheseDetails(post){
            this.selectedPost = post;
            this.displayDetails = true;
            this.displaySavedPosts = false;
            this.displayUserPosts = false;
            
            // in this method, we need to show the post full details view

        }
    },
    created(){
        ApiServices.getUserPosts(this.userId, this.$store.state.token).then(result => {
            result.data.forEach(element => {
                element.photo.photo = `${this.$store.state.photoBase}${element.photo.photo}`;
            });
            this.posts = result.data;
        });

        ApiServices.getUserFavoitePosts(this.userId, this.$store.state.token).then(result => {
            result.data.forEach(element => {
                element.photo.photo = `${this.$store.state.photoBase}${element.photo.photo}`;
            });
            this.favoritePosts = result.data;
        })



    }
}
</script>

<style>
#display-user-posts-container{
    /* background-color: #FEF19A;
    border: #A8248E solid 1px; */
    border-radius: 20px;
    padding: 1%
}
#posts-or-saved-container{
    display: flex;
    justify-content: bottom;
    /* background-color: rgba(128, 128, 128, 0.164); */
    /* border-top-left-radius: 10px;
    border-top-right-radius: 10px;  */
    border-bottom: 4px solid #ddcbef; 
    border-right: 4px solid white;  
    border-left: 4px solid white;
}
.not-selected-view{
    width: 45%;
}
.selected-view{
    width:45%;
    background-color: #ddcbef2a;
    border-top-left-radius: 20px;
    border-top-right-radius: 20px; 
}   

#posts-container{
/* margin: 5px; */
/* display: grid; */
/* grid-template-columns: 1fr 1fr 1fr; */
margin-top: 10px;
width: 100%;
display: flex;
flex-wrap: wrap;
justify-content: center; 
}
#posts-container img{
    width: 30%;
    max-height: 400;
    margin: 2px 2px 2px 2px;
    /* border: #FEF19A solid 2px; */
    /* border-radius: 20px; */
    object-fit: cover;
}
#my-posts{
    font-size: 1.25rem;
}

</style>