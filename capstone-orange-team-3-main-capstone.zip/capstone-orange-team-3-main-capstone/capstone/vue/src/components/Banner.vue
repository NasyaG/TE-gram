<template>
    <div id="banner">
        <router-link v-bind:to="{ name: 'home' }">
            <img v-show="$store.state.token != ''" id="TEgramLogo" src="../assets/TEfinal-logo2.png" alt="">  
        </router-link>
        
  </div>
</template>

<script>
export default {
    name: 'banner',
}
</script>

<style>

#banner{
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: white;
    position: fixed;
    height: 2rem;
    top: 0;
    width: 100%;
    z-index: 1;
}
#TEgramLogo{
    
    height: 2rem;
    padding: 0 0 0 0;
    
    margin: 0 0 0 0;
 
}

</style>