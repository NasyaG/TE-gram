<template>
<div>
    <div id="user-details-container">
      <h3 id="profile-username">{{$store.state.user.username}}</h3>
      <img v-bind:src="profilePhoto" alt="users profile photo" id="profile-photo" v-show="displayProfilePhoto">
    </div>
</div>

</template>

<script>
export default {
    name: 'display-user-details',
    computed:{
        profilePhoto(){
            return this.$store.state.profilePhoto;
        },
        displayProfilePhoto(){
            if(this.$store.state.profilePhoto == ''){
                return false;
            }else{
                return true;
            }
        }
    },
}
</script>

<style>
*{
    font-family: 'Roboto Condensed', sans-serif;
}
#user-details-container{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    width: 10%;
    margin: 0;
    padding: 0 0 0 0px;
    position:fixed;
    top: 0 ;
    right: 2vw ;
    z-index: -1;
    
}
h3{
    color: #A8248E;
}
p{
    color: #A8248E;
}
#profile-photo{
    width: 10vw;
    height: 10vw;
    border-radius: 75px;
    object-fit: cover;
    margin-top: 10px;
    border: solid white 3px;
}
@media only screen and (max-width : 600px) {
    #profile-photo{
        display: none;
    }
}
@import url('https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@300;400;700&display=swap');
</style>