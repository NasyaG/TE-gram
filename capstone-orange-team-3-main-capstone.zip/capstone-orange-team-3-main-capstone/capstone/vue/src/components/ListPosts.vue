<template>
  <div>
      <div v-if="!isLoading">
          <display-post  v-for="post in posts" v-bind:key="post.id" v-bind:post="post" />
      </div>
      <div v-if="isLoading" id="loading-image-container">
            <img  src="../assets/spinner-loading.gif" alt="loading image" id="loading-image">
      </div>
      
  </div>
</template>

<script>
import ApiServices from '../services/ApiServices'
import DisplayPost from './DisplayPost.vue'
export default {
  components: { DisplayPost },
    name: 'list-posts',
    data(){
        return{
            isLoading: true,
            posts: []
        }
    },
    methods: {
        saveProfilePhoto(photo){
            this.$store.commit("SET_PROFILE_PHOTO", photo);
        }
    },
    created(){
        //alert(this.$store.state.token)
        let totalLikes = 0;
        ApiServices.getPosts(this.$store.state.token).then(result =>{
            result.data.forEach(element => {
                element.photo.photo = `${this.$store.state.photoBase}${element.photo.photo}`;
            });
            this.posts = result.data;
            this.isLoading = false;
            console.log(result);
        });
        ApiServices.getUserPosts(this.$store.state.user.userId, this.$store.state.token).then(result => {    
            result.data.forEach(element => {
                element.photo.photo = `${this.$store.state.photoBase}${element.photo.photo}`;
                totalLikes += element.post.likes;
            });
            this.$store.commit("SET_TOTAL_LIKES", totalLikes);
            this.saveProfilePhoto(result.data[(result.data.length - 1)].photo.photo);
        });
    }
}    
    
</script>

<style>
#loading-image-container{
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}
#loading-image{
    height: 100px;
    width: auto;
}
</style>