<template>
  <div id="post-full-details-container">
     <display-post v-bind:post="post"/>
     <list-comments/>
  </div>
</template>

<script>
import DisplayPost from './DisplayPost.vue'
import ListComments from './ListComments.vue'
export default {
  components: { DisplayPost, ListComments },
  name: 'post-full-details',
  props:['post']
}
</script>

<style>
</style>