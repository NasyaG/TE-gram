<template>
  <div id="comment-container">
      <span id="user-name-text">{{comment.username}}</span>
      <span id="comment">{{comment.comment}}</span>
  </div>
</template>

<script>
export default {
    name: 'display-comment',
    props: ["comment"]
}
</script>

<style>
#user-name-text{
    font-weight: 700;
    margin: 0 0 0 0;
    color: #A8248E ;
}
#comment{
   margin: 0 0 0 1rem;
   color: #A8248E ;

}
#comment-container{
    display: flex;
    flex-direction: row;
    background-color: white;
    border-radius: 5px;
    margin: 0;
}
</style>