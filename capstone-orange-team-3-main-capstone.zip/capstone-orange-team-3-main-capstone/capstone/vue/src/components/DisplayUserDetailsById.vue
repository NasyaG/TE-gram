<template>
    <div id="user-id-details-container">
      <h2 id="user-id-details-username">{{username}}</h2>
      <!-- <p>{{user.bio}}</p> -->
  </div>
</template>

<script>
import ApiServices from '../services/ApiServices'
export default {
    name: 'display-user-details-by-id',
    props: ["userId"],
    data(){
        return{
            username: ''
        }
    },
    created(){
        ApiServices.getUsername(this.userId, this.$store.state.token).then(result => {
            this.username = result.data;
        });
    }

}
</script>

<style>
    *{
        font-family: 'Roboto Condensed', sans-serif;
    }
    #user-id-details-container{
        margin: 1rem;
        padding: 0 0 0 10px;
        display:flex;
        justify-content: center;
    }
    h3{
        color: #A8248E;
    }
    #user-id-details-username{
        color: #A8248E;
    }
    p{
        color: #A8248E;
    }
@import url('https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@300;400;700&display=swap');
</style>