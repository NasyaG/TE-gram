import axios from 'axios';

const http = axios.create({
  baseURL: "https://localhost:44315"
});

export default {

  // TEgram POST Services
  getPosts(headerToken) {
    const headers = {
      headers:{
        Authorization: 'Bearer ' + headerToken
      }
    }
    return http.get('/posts', headers);
  },

  getPost(postId, headerToken) {
    const headers = {
      headers:{
        Authorization: 'Bearer ' + headerToken
      }
    }
    return http.get(`/posts/${postId}`, headers);
  },

  addPost(post, headerToken) {
    const headers = {
      headers:{
        Authorization: 'Bearer ' + headerToken
      }
    }
    return http.post('/posts', post, headers);
  },

  getUserPosts(userId, headerToken) {
    const headers = {
      headers:{
        Authorization: 'Bearer ' + headerToken
      }
    }
    return http.get(`/posts/user/${userId}`, headers);
  },

  getUserFavoitePosts(userId, headerToken) {
    const headers = {
      headers:{
        Authorization: 'Bearer ' + headerToken
      }
    }
    return http.get(`/posts/user/${userId}/favorited`, headers);
  },

  // TEgram PHOTO Services
  addPhoto(formData, headerToken) {
    const headers = {
      headers:{
        Authorization: 'Bearer ' + headerToken
      }
    }
    return http.post('/posts/upload', formData, headers);
  },
  getPhoto(photoId, headerToken) {
    const headers = {
      headers:{
        Authorization: 'Bearer ' + headerToken
      }
    }
    return http.get(`/posts/photos/${photoId}`, headers);
  },

  // TEgram COMMENT services
  addComment(comment, headerToken) {
    const headers = {
      headers:{
        Authorization: 'Bearer ' + headerToken
      }
    }
    return http.post('/comments', comment, headers);
  },

  // TEgram FAVORITE services
  favoritePost(postId, userId){
    return http.put(`/posts/favorite/${postId}/${userId}`);
  },
  unfavoritePost(postId, userId){
    return http.put(`/posts/unfavorite/${postId}/${userId}`);
  },

  // TEgram LIKE Services
  //workaround- should be like comments above^^^line81
  likePost(postId, userId ){
    return http.put(`/posts/like/${postId}/${userId}`);
  },
  unlikePost(postId, userId){
    return http.put(`/posts/unlike/${postId}/${userId}`);
  },

  // TEgram PROFILE Services
  getUsername(userId, headerToken){
    const headers = {
      headers:{
        Authorization: 'Bearer ' + headerToken
      }
    }
    return http.get(`/posts/user/${userId}/username`, headers);
  },
 

}