<template>
  <div id="app">
    
    <banner id="banner" />

    <div id="sidebar">
      <sidebar />
    </div>
    
    <router-view id="router-view-body"/>
    
    <display-user-details id="display-user-details-sidebar" v-show="$store.state.token != ''"/>
    
    <nav-bar id="nav-bar-footer"/>
  </div>
</template>

<script>
  import Sidebar from '@/components/Menu/Sidebar.vue';
  import Banner from './components/Banner.vue';
  import NavBar from './components/NavBar.vue';
  import DisplayUserDetails from './components/DisplayUserDetails.vue';

  export default {
    name: 'app',
    components: {
      Sidebar,
      Banner,
      NavBar,
      DisplayUserDetails,
    },
    data(){
      return{
        profilePhoto: '',
        likeNotificationsSb: true,
        commentNotificationsSb: true,
        displayUserDetailsSb: true
      }
    },

    created() {
      window.addEventListener('resize', this.$store.commit('SET_WINDOW_WIDTH'));
    },
  }
</script>

<style>
body{
  margin: 0 0 0 0;
  padding: 0 0 0 0;
}
#app{
  width: 100%;
  display: grid;
  grid-template-columns: 2fr 3fr 3fr 2fr;
  grid-template-areas:
    "header header header header"
    "sidebar content content userInfo"
    "sidebar content content ."
    "footer footer footer footer";
}
#banner {
  grid-area: header;
  width: 100vw;
}
#sidebar {
  grid-area: sidebar;
}
#router-view-body {
  grid-area: content;
  height: 100%;
  margin: 2rem 0 2rem 0;
}
#display-user-details-sidebar{
  grid-area: userInfo;
  width: 100%;
  
  margin-top: 2rem;
  padding: 0;
  z-index: 2;
}
#nav-bar-footer {
  grid-area: footer;
  display: flex;
  width: 100%;
  justify-content: space-evenly;
  position: fixed;
  bottom: 0%;
  background-color: white;
}

@media only screen and (max-width: 600px){
#app{
  grid-template-areas:
    ". header header userInfo"
    "content content content content"
    "footer footer footer footer";
  }
  #display-user-details-sidebar{
    top: -10px;
    right:0;
    margin: 0;
    padding: 0;
    z-index: 2;
  }

}
</style>