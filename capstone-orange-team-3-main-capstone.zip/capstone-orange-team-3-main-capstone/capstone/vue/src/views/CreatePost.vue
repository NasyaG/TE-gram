<template>
  <div class="new-post-title-container">
      <h3 id="new-post-title">New post</h3>
      <upload-post />
 
  </div>
</template>

<script>

import UploadPost from '../components/UploadPost.vue'
export default {
  components: {  UploadPost },
    name: 'create-post',
}
</script>

<style>
.new-post-class-container{
  border: 3px;
  display: flex;
  justify-items: left;
 

}
#new-post-title{
  width: 100%;
  text-align: center;
  align-items:center;
  justify-content: center;
  margin: 1rem 0 0 0;
  color: #A8248E;
}
</style>