<template>
  <div>
      <p>like notification list</p>
      <p>like notification list</p>
      <p>like notification list</p>
      <p>like notification list</p>
      <p>like notification list</p>
      <p>like notification list</p>
  </div>
</template>

<script>
  export default {
      name: 'like-notifications'
  }
</script>

<style>

</style>