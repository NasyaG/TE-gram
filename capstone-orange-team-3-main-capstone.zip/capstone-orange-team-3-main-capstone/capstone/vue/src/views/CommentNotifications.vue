<template>
  <div>
    <div id="outermost-div" v-if="!isLoading">
      <h2>Comments</h2>
      <div v-for="post in posts" :key="post.post.id" class="comment-notification-container">
        <img :src="post.photo.photo" :key="post.photo.photoId" alt="" id="thumbnail" v-if="post.commentsList[0] != null"/> 
        <div id="caption-and-comments-container" v-if="post.commentsList[0] != null" >
          <div id="comment-container">
            <h4 id="post-username">{{post.username}}</h4><h4 id="caption" >{{post.post.caption}}</h4>
          </div>
          <list-comments-notifications :post="post" />
        </div>
      </div>
    </div>

    <div v-if="isLoading" id="loading-image-container">
      <img  src="../assets/spinner-loading.gif" alt="loading image" id="loading-image">
    </div>
  </div>
</template>

<script>
import ListCommentsNotifications from '../components/ListCommentsNotifications.vue';
import ApiServices from '../services/ApiServices';
  export default {
  components: { ListCommentsNotifications },
  name: 'comment-notifications',
  data(){
    return{
      isLoading: true,
      posts: []
    }
  },
  created(){
        ApiServices.getUserPosts(this.$store.state.user.userId, this.$store.state.token).then(result => {
            result.data.forEach(element => {
                element.photo.photo = `${this.$store.state.photoBase}${element.photo.photo}`;
            });
            this.posts = result.data;
            this.isLoading = false;
        });
  },
}
  
</script>

<style>
#thumbnail{
  width: 4rem;
  height: 4rem;
  object-fit: cover;
}
.comment-notification-container{
  color: #A8248E;
  margin: 1rem;
  display: flex;
  flex-direction: row;
  align-items: top;
  width: 100%;
  max-width: 600px; 
}
#comment-container{
  display: flex;
  align-items: top;
}
#post-username{
  margin:0;
}
#profile-username{
  margin:0;
}
#caption{
  margin:0;
  margin-left: 1rem;
  font-weight: 400;
}
h2{
  color: #A8248E;
}

#caption-and-comments-container{
  margin: 0 1rem 0 1rem;
}
#outermost-div{
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
</style>