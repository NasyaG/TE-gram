<template>
<div> 
  <div id="logo-container">
  
       <form class="">
             <div class="container"> 
              <div class="it-support-container">
             <header><img id="logo" src="../assets/TEfinal-logo2.png" alt=""></header>
            <label for="name" class="sr-only"></label> 
                <input 
                type="name"
                id="name"
                class="form-control"
                placeholder="name"
                v-model="user.name"
                required
                />
                <div>
            <label for="email" class="sr-only"></label> 
                <input 
                type="email"
                id="email"
                class="form-control"
                placeholder="email"
                v-model="user.name"
                required
                />
                </div>  
                <button class="button" type="submit">Reset Password</button>
             <p>Remember your password?
             <router-link class="router-link" :to="{ name: 'login' }"  v-if="$store.state.token == ''" >Login</router-link>
             </p>
           <p>Don't have an account?
            <router-link class="router-link" :to="{ name: 'register' }"  v-if="$store.state.token == ''" >Sign Up</router-link>
            </p>
          </div>
          
          </div>
          
        </form>

        
    </div>
</div>
    
</template>

<script>
export default {
  name: "itSupport",
  components:{},
    data() {
        return {
           user: {
               name: "",
               password: ""
           }
        }
    },
    methods: {

    }



};
</script>

<style scoped>
#logo-container{
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
 
}


.it-support-container{
    display: flex;
    flex-direction: column;
    align-items: center;
  
    width: 100%;
    max-width: 350px;
    height: 300px;
    background: #F8DEF3;
    border: #A8248E solid 2px;
    border-radius: 20px;
    border-style: groove;
    

}

h1 {
  color:#A8248E;
  margin-top: 10px;
}
#forgot{
  margin: 0px;
  
}
section{
  display: flex;
  justify-content: center;
  flex-direction: column;
}
#name{
   background-color:#FBF8CC;
  color: #A8248E;
  border-radius: 20px;
  border: 1px solid #A8248E;
  width: 100px;
 padding: 5px 10px 5px 10px;
  margin: 5px 10px 5px 10px;

}
#email{
   background-color: #FBF8CC;
  color: #A8248E;
  border-radius: 20px;
  border: 1px solid #A8248E;
    width: 100px;
   padding: 5px 10px 5px 10px;
  margin: 5px 10px 5px 10px;

}
#logo {
 
  height: 2rem;
  padding: 1vh;
}
.button{
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 125px;
  background-color: #FBF8CC;
  color: #A8248E;
  border-radius: 20px;
  border: 1px solid  #A8248E;
  padding: 5px 10px 5px 10px;
  margin: 5px 5px 5px 5px;
  
  
}

</style>