<template>
  <div id="profile-container">
    <display-user-details-by-id v-bind:userId="userId" />
    <display-user-posts-by-id v-bind:userId="userId"/>
  </div>
</template>

<script>

import DisplayUserDetailsById from '../components/DisplayUserDetailsById.vue'
import DisplayUserPostsById from '../components/DisplayUserPostsById.vue'

export default {
  components: { DisplayUserDetailsById, DisplayUserPostsById},
  name: 'profile-by-id',
  props: ["userId"]
}
</script>

<style>

</style>