<template>
  <div id="profile-container">
    
    <display-user-posts id="display-user-posts-component" />
  </div>
</template>

<script>
import DisplayUserPosts from '../components/DisplayUserPosts.vue'
export default {
  components: { DisplayUserPosts},

}
</script>

<style>
#display-user-posts-component{
  padding-top: 10%;
}
</style>