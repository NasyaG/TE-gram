<template>
<div>
  <div id="logo-container">
  <div id="register-container">
    
    <form class="form-register" @submit.prevent="register">
      <header><img id="logo" src="../assets/TEfinal-logo2.png" alt=""/></header>
     
     
      <div class="alert alert-danger" role="alert" v-if="registrationErrors">
        {{ registrationErrorMsg }}
      </div>
    

     <section>
      
      <label for="username" class="sr-only"></label>
      <input
        type="text"
        id="username"
        class="form-control register-account-input-field"
        placeholder="Username"
        v-model="user.username"
        required
        autofocus
      />

      <label for="password" class="sr-only"></label>
      <input
        type="password"
        id="password"
        class="form-control register-account-input-field"
        placeholder="Password"
        v-model="user.password"
        required
      />
      
      <input
        type="password"
        id="confirmPassword"
        class="form-control register-account-input-field"
        placeholder="Confirm Password"
        v-model="user.confirmPassword"
        required
      />
      
      <label for="email" class="sr-only"></label>
      
      <input
        type="email"
        id="email"
        class="form-control register-account-input-field"
        placeholder="Email"
        v-model="user.email"
        required
        autofocus
      />
    
        <div>
      <button class="create-account" type="submit">
              Create Account     
      </button>
       </div>
      </section>
      <div id="have-an-account">
      <p>Have an account?
             <router-link class="router-link" :to="{ name: 'login' }" id="login-link" v-if="$store.state.token == ''" >Login</router-link>
             </p>
      </div>       
    </form>
  </div>
  </div>
  </div>
</template>

<script>
import authService from '../services/AuthService';

export default {
  name: 'register',
  data() {
    return {
      user: {
        username: '',
        password: '',
        confirmPassword: '',
        role: 'user',
      },
      registrationErrors: false,
      registrationErrorMsg: 'There were problems registering this user.',
    };
  },
  methods: {
    register() {
      if (this.user.password != this.user.confirmPassword) {
        this.registrationErrors = true;
        this.registrationErrorMsg = 'Password & Confirm Password do not match.';
      } else {
        authService
          .register(this.user)
          .then((response) => {
            if (response.status == 201) {
              this.$router.push({
                path: '/login',
                query: { registration: 'success' },
              });
            }
          })
          .catch((error) => {
            const response = error.response;
            this.registrationErrors = true;
            if (response.status === 400) {
              this.registrationErrorMsg = 'Bad Request: Validation Errors';
            }
          });
      }
    },
    clearErrors() {
      this.registrationErrors = false;
      this.registrationErrorMsg = 'There were problems registering this user.';
    },
  },
};
</script>

<style scoped>
#logo-container{
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
}
#have-an-account{
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
#register-container{
  display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-evenly;
    width: 100%;
    max-width: 350px;
    height: 300px;
    background: #F8DEF3;
    border: #A8248E solid 2px;
    border-radius: 20px;
    border-style: groove;
    padding: 10, 10, 10, 10;
   
}
header{
  display: flex;
  justify-content: center;
}
section{
  display: flex;
  justify-content: center;
  flex-direction: column;
}
.register-account-input-field{
  background-color: #FBF8CC;
  color: #A8248E;
  border-radius: 20px;
  border: 1px solid #A8248E;
  padding: 5px 10px 5px 10px;
  margin: 5px 10px 5px 10px;
}
/* #username{
  background-color: #FBF8CC;
}
#password{
  background-color: #FBF8CC;
}
#confirmPassword{
   background-color: #FBF8CC;
  color: #A8248E;
  border-radius: 20px;
  border: 1px solid #A8248E;
  padding: 5px 10px 5px 10px;
  margin: 5px 10px 5px 10px;
  
}
#email{
   background-color: #FBF8CC;
  color: #A8248E;
  border-radius: 20px;
  border: 1px solid #A8248E;
  padding: 5px 10px 5px 10px;
  margin: 5px 10px 5px 10px;
} */
button.create-account{
   background-color: #FBF8CC;
  color: #A8248E;
  border-radius: 20px;
  width: 160px;
  border: 1px solid #A8248E;
  box-shadow: #A8248E 2px 2px;
  padding: 5px 10px 5px 10px;
  margin: 5px 10px 5px 10px;

}

#logo {
 
  height: 2rem;
  padding: 1vh;
}
</style>
