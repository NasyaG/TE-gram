<template>
  <div class="home">
    <list-posts />
  

  </div>
</template>

<script>
import ListPosts from '../components/ListPosts.vue';
export default {
  components: { ListPosts },
  name: "home"
};
</script>



<style>
</style>

